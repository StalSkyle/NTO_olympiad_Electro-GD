using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Hamster.NoneCoroutine;

namespace System.Hamster
{
    public class HitInfo
    {
        public GameObject otherObject;
        public object otherInformation;
        public HitInfo(Collision collision)
        {
            otherObject = collision.gameObject;
            otherInformation = collision;
        }
        public HitInfo(Collider other)
        {
            otherObject = other.gameObject;
            otherInformation = other;
        }
        public HitInfo(Collision2D collision)
        {
            otherObject = collision.gameObject;
            otherInformation = collision;
        }
        public HitInfo(Collider2D other)
        {
            otherObject = other.gameObject;
            otherInformation = other;
        }
    }

    public class CanBeDone
    {
        protected Action action;
        public CanBeDone()
        {
            this.action = null;
        }
        public CanBeDone(Action action)
        {
            this.action = action;
        }
        public void Execute()
        {
            this.action();
        }
    }

    public class UltraBehaviour : MonoBehaviour
    {
        private bool isHitted = false;
        public Func<bool> IsHitted;

        public static void WeWantTo(params CanBeDone[] whatToDo)
        {
            foreach (var deal in whatToDo)
            {
                deal.Execute();
            }
        }

        protected static Vector3 GetRealSizeOf(GameObject gameObject)
        {
            Vector3 mbs = gameObject.GetComponent<MeshFilter>().sharedMesh.bounds.size;
            mbs.x *= gameObject.transform.lossyScale.x;
            mbs.y *= gameObject.transform.lossyScale.y;
            mbs.z *= gameObject.transform.lossyScale.z;
            return mbs;
        }
        protected static void IncludeOnPhisicFor(GameObject gameObject)
        {
            Collider collder;
            if (!gameObject.TryGetComponent<Collider>(out collder))
            {
                collder = gameObject.AddComponent<Collider>();
            }
            Rigidbody rigidbody;
            if(!gameObject.TryGetComponent<Rigidbody>(out rigidbody))
            {
                rigidbody = gameObject.AddComponent<Rigidbody>();
            }
            collder.isTrigger = false;
        }
        protected static void IncludeOnTriggerFor(GameObject gameObject)
        {
            Collider collder;
            if (!gameObject.TryGetComponent<Collider>(out collder))
            {
                collder = gameObject.AddComponent<Collider>();
            }
            collder.enabled = true;
            collder.isTrigger = true;
        }
        protected static void SetVisible(GameObject gameObject, bool value = true)
        {
            Renderer renderer;
            if (gameObject.TryGetComponent<Renderer>(out renderer))
            {
                renderer.enabled = value;
            }
        }
        protected static System.Threading.Tasks.Task WaitForSeconds(float seconds)
        {
            return System.Threading.Tasks.Task.Delay(Mathf.RoundToInt(seconds*1000));
        }
        protected static System.Threading.Tasks.Task WaitForMilliseconds(int milliseconds)
        {
            return System.Threading.Tasks.Task.Delay(milliseconds);
        }

        protected void ChangeXOn(float value)
        {
            transform.position += new Vector3(value, 0, 0);
        }
        protected void ChangeYOn(float value)
        {
            transform.position += new Vector3(0, value, 0);
        }
        protected void ChangeZOn(float value)
        {
            transform.position += new Vector3(0, 0, value);
        }
        protected void ChangePositionOn(Vector3 value)
        {
            transform.position += value;
        }
        protected Call dChangeXOn(float value)
        {
            return new Call(() => ChangeXOn(value));
        }
        protected Call dChangeYOn(float value)
        {
            return new Call(() => ChangeYOn(value));
        }
        protected Call dChangeZOn(float value)
        {
            return new Call(() => ChangeZOn(value));
        }
        protected Call dChangePositionOn(Vector3 value)
        {
            return new Call(() => ChangePositionOn(value));
        }

        public virtual void OnHit(HitInfo info) { }
        public virtual void OnStart() { }
        public virtual void OnUpdate() { }
        public virtual async System.Threading.Tasks.Task OnStep() { }

        private void Start()
        {
            IsHitted = delegate { return isHitted; };
            OnStart();
            System.Threading.Tasks.Task.Run(Step);
        }
        private void FixedUpdate()
        {
            OnUpdate();
        }
        private async void Step()
        {
            while (true)
            {
                await OnStep();
            }
        }
        private void OnCollisionEnter(Collision collision)
        {
            isHitted = true;
            OnHit(new HitInfo(collision));
        }
        private void OnCollisionExit(Collision collision)
        {
            isHitted = false;
        }
        private void OnTriggerEnter(Collider other)
        {
            isHitted = true;
            OnHit(new HitInfo(other));
        }
        private void OnTriggerExit(Collider other)
        {
            isHitted = false;
        }
        private void OnCollisionEnter2D(Collision2D collision)
        {
            isHitted = true;
            OnHit(new HitInfo(collision));
        }
        private void OnCollisionExit2D(Collision2D collision)
        {
            isHitted = false;
        }
        private void OnTriggerEnter2D(Collider2D collision)
        {
            isHitted = true;
            OnHit(new HitInfo(collision));
        }
        private void OnTriggerExit2D(Collider2D collision)
        {
            isHitted = false;
        }
    }

    public class Call : CanBeDone
    {
        float delay = -1;
        Action whatWeWantToCall;
        Func<bool> when_condition;
        Func<bool> until_condition;
        private void CallI()
        {
            if (delay > 0 || when_condition != null || until_condition != null)
            {
                var ev = new ETools.Event(whatWeWantToCall, Mathf.Max(delay, 0), ETools.EventType.Regular);
                if (when_condition != null)
                    ev.ExecuteWhen(when_condition);
                if (until_condition != null)
                    ev.RemoveWhen(until_condition);
                ETools.AddEvent(ev);
            }
            else
            {
                whatWeWantToCall();
            }
        }
        public Call(Action action)
        {
            whatWeWantToCall = action;
            this.action = CallI;
        }
        public Call Every(float delay)
        {
            this.delay = delay;
            return this;
        }
        public Call When(Func<bool> condition)
        {
            this.when_condition = condition;
            return this;
        }
        public Call Until(Func<bool> condition)
        {
            this.until_condition = condition;
            return this;
        }
    }
}