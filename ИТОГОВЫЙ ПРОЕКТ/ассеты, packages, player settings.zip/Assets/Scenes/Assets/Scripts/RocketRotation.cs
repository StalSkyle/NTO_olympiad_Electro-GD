using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RocketRotation : MonoBehaviour
{
    int updates;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        if(Time.deltaTime * updates < 22)
            transform.Rotate(Vector3.forward, Time.deltaTime * 20);
    }
}
