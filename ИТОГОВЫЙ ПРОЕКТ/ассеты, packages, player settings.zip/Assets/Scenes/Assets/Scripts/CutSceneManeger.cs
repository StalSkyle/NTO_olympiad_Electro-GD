using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class CutSceneManeger : MonoBehaviour
{
    float startTimePoint = 0;
    public Image darkness;

    // Start is called before the first frame update
    void Awake()
    {
        startTimePoint = Time.time;
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        if (SceneManager.GetActiveScene().name == "FirstTimelinePart1")
        {
            if (Time.time - startTimePoint >= 25.04f)
            {
                StartCoroutine(Blackout());
            }
        }
        else
        {
            if (Time.time - startTimePoint >= 14.95f)
            {
                StartCoroutine(Blackout());
            }
        }
    }

    IEnumerator Blackout()
    {
        for (int i = 0; i < 100; ++i)
        {
            darkness.color = new Color(0, 0, 0, darkness.color.a + 0.01f);
            Debug.Log(darkness.color);
            yield return new WaitForSeconds(0.03f);
        }
        if (SceneManager.GetActiveScene().name == "FirstTimelinePart1")
        {
            SceneManager.LoadScene("FirstTimelinePart2");
        }
        else
        {
            SceneManager.LoadScene("Game");
        }
    }

    IEnumerator Blackout2()
    {
        for (int i = 0; i < 100; ++i)
        {
            darkness.color = new Color(0, 0, 0, darkness.color.a + 0.01f);
            Debug.Log(darkness.color);
            yield return new WaitForSeconds(0.03f);
        }
        SceneManager.LoadScene("Game");
    }

    public void OnSkipButtonClicked()
    {
        StartCoroutine(Blackout2());
    }
}
