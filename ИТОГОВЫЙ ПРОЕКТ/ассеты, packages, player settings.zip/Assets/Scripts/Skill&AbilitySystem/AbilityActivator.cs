using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.Linq;

public class AbilityActivator : MonoBehaviour
{
    public Image ability_button_mask;
    public float reboot_delay;
    float last_activation;
    public int activation_max_count;
    public int activation_count;
    public int ability_type;

    public List<Sprite> ability_sprites;

    public MessageController message;

    // Start is called before the first frame update
    void Start()
    {
        last_activation = 0;
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        if (activation_count < activation_max_count)
        {
            ability_button_mask.fillAmount = 1 - (Time.time - last_activation) / reboot_delay;
        }
        else
        {
            ability_button_mask.fillAmount = 1;
        }
        if (ability_type > -1)
        {
            GetComponent<Image>().sprite = ability_sprites[ability_type];
        }
    }

    public void ActivateAbility()
    {
        if (Time.time - last_activation >= reboot_delay && activation_count < activation_max_count)
        {
            switch (ability_type)
            {
                case 0:
                    float closest = 0f;
                    GameObject line;
                    switch (Singleton.skills.blocks_destroyer) {
                        case 1:
                            closest = Singleton.generator.lines.Where(x => x != null && x.transform.position.y > Singleton.player.transform.position.y).Min(x => x.transform.position.y);
                            line = Singleton.generator.lines.Find(x => x != null && x.transform.position.y == closest);
                            Singleton.generator.lines.Remove(line);
                            Destroy(line);
                            break;
                        case 2:
                            for (int i = 0; i < 2; ++i)
                            {
                                closest = Singleton.generator.lines.Where(x => x != null && x.transform.position.y > Singleton.player.transform.position.y).Min(x => x.transform.position.y);
                                line = Singleton.generator.lines.Find(x => x.transform.position.y == closest);
                                Singleton.generator.lines.Remove(line);
                                Destroy(line);
                            }
                            break;
                        case 3:
                            foreach(var gline in Singleton.generator.lines)
                            {
                                Destroy(gline);
                            }
                            Singleton.generator.lines.Clear();
                            break;
                    }
                    break;
                case 1:
                    switch (Singleton.skills.damage_shield)
                    {
                        case 1:
                            StartCoroutine(Execute(() => {
                                Singleton.player.damage_shield = 0.4f;
                            }, () => {
                                Singleton.player.damage_shield = 0f;
                            }, 3));
                            break;
                        case 2:
                            StartCoroutine(Execute(() => {
                                Singleton.player.damage_shield = 0.7f;
                            }, () => {
                                Singleton.player.damage_shield = 0f;
                            }, 3));
                            break;
                        case 3:
                            StartCoroutine(Execute(() => {
                                Singleton.player.damage_shield = 0.7f;
                            }, () => {
                                Singleton.player.damage_shield = 0f;
                            }, 7));
                            break;
                        case 4:
                            StartCoroutine(Execute(() => {
                                Singleton.player.damage_shield = 1f;
                                Singleton.player.GetComponent<MeshCollider>().enabled = false;
                            }, () => {
                                Singleton.player.GetComponent<MeshCollider>().enabled = true;
                                Singleton.player.damage_shield = 0f;
                            }, 3));
                            break;
                    }
                    break;
                case 2:
                    switch (Singleton.skills.carbon_price_upper)
                    {
                        case 1:
                            StartCoroutine(Execute(() => {
                                BoostsController.carbon_price = 2;
                            }, () => {
                                BoostsController.carbon_price = 1;
                            }, 4f));
                            break;
                        case 2:
                            StartCoroutine(Execute(() => {
                                BoostsController.carbon_price = 3;
                            }, () => {
                                BoostsController.carbon_price = 1;
                            }, 4f));
                            break;
                    }
                    break;
            }
            ++activation_count;
            last_activation = Time.time;
        }
        else if (activation_count >= activation_max_count)
        {
            message.ViewMessage("� ��� ����������� �����������, �� 1 ����� �� ����� - 3 �����.");
        }
        else
        {
            message.ViewMessage(string.Format("�� ����� ����������� �������� {0} ������.", (int)(reboot_delay - (Time.time - last_activation))));
        }
    }

    IEnumerator Execute(System.Action action, System.Action reation, float period)
    {
        action();
        yield return new WaitForSeconds(period);
        reation();
    }
}
