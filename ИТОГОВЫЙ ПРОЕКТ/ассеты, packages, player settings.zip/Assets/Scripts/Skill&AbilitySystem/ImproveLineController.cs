using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ImproveLineController : MonoBehaviour
{
    public int characteristic;
    public int value;
    public int price;
    public ProgressBarController progress;
    public Text text;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void TryUpgrade(float coef)
    {
        switch (characteristic)
        {
            case 0:
                if(is_carbon_enough(Singleton.skills.blocks_destroyer_max, coef))
                {
                    if (coef > 0 && Singleton.skills.blocks_destroyer < Singleton.skills.blocks_destroyer_max)
                    {
                        Singleton.player.carbon -= Mathf.RoundToInt(coef * value * progress.value / 100f * Singleton.skills.blocks_destroyer_max) + 5;
                        ++Singleton.skills.blocks_destroyer;
                        if (Singleton.player.chosen_ability == -1)
                        {
                            Singleton.player.chosen_ability = 0;
                        }
                    }
                    else if(coef < 0 && Singleton.skills.blocks_destroyer > 0)
                    {
                        --Singleton.skills.blocks_destroyer;
                        Singleton.player.carbon -= (int)coef;
                    }
                    progress.value = (float)Singleton.skills.blocks_destroyer / Singleton.skills.blocks_destroyer_max * 100f;
                    if (Singleton.skills.blocks_destroyer < Singleton.skills.blocks_destroyer_max)
                    {
                        text.text = string.Format("����������� ������ ({0} ���.)", Mathf.RoundToInt(price * value * progress.value / 100f * Singleton.skills.blocks_destroyer_max) + 5);
                    }
                    else
                    {
                        text.text = "����������� ������ (����.)";
                    }
                }
                break;
            case 1:
                if (is_carbon_enough(Singleton.skills.damage_shield_max, coef))
                {
                    if (coef > 0 && Singleton.skills.damage_shield < Singleton.skills.damage_shield_max)
                    {
                        Singleton.player.carbon -= Mathf.RoundToInt(coef * value * progress.value / 100f * Singleton.skills.damage_shield_max) + 5;
                        ++Singleton.skills.damage_shield;
                        if (Singleton.player.chosen_ability == -1)
                        {
                            Singleton.player.chosen_ability = 1;
                        }
                    }
                    else if (coef < 0 && Singleton.skills.damage_shield > 0)
                    {
                        --Singleton.skills.damage_shield;
                        Singleton.player.carbon -= (int)coef;
                    }
                    progress.value = (float)Singleton.skills.damage_shield / Singleton.skills.damage_shield_max * 100f;
                    if (Singleton.skills.damage_shield < Singleton.skills.damage_shield_max)
                    {
                        text.text = string.Format("������������� ��� ({0} ���.)", Mathf.RoundToInt(price * value * progress.value / 100f * Singleton.skills.damage_shield_max) + 5);
                    }
                    else
                    {
                        text.text = "������������� ��� (����.)";
                    }
                }
                break;
            case 2:
                if (is_carbon_enough(Singleton.skills.carbon_price_upper_max, coef))
                {
                    if (coef > 0 && Singleton.skills.carbon_price_upper < Singleton.skills.carbon_price_upper_max)
                    {
                        Singleton.player.carbon -= Mathf.RoundToInt(coef * value * progress.value / 100f * Singleton.skills.carbon_price_upper_max) + 5;
                        ++Singleton.skills.carbon_price_upper;
                        if (Singleton.player.chosen_ability == -1)
                        {
                            Singleton.player.chosen_ability = 2;
                        }
                    }
                    else if (coef < 0 && Singleton.skills.carbon_price_upper > 0)
                    {
                        --Singleton.skills.carbon_price_upper;
                        Singleton.player.carbon -= (int)coef;
                    }
                    progress.value = (float)Singleton.skills.carbon_price_upper / Singleton.skills.carbon_price_upper_max * 100f;
                    if (Singleton.skills.carbon_price_upper < Singleton.skills.carbon_price_upper_max)
                    {
                        text.text = string.Format("������������� �������� ({0} ���.)", Mathf.RoundToInt(price * value * progress.value / 100f * Singleton.skills.carbon_price_upper_max) + 5);
                    }
                    else
                    {
                        text.text = "������������� �������� (����.)";
                    }
                }
                break;
            case 3:
                if (is_carbon_enough(Singleton.skills.radiation_shield_max, coef))
                {
                    if (coef > 0 && Singleton.skills.radiation_shield < Singleton.skills.radiation_shield_max)
                    {
                        Singleton.player.carbon -= Mathf.RoundToInt(coef * value * progress.value / 100f * Singleton.skills.radiation_shield_max) + 5;
                        ++Singleton.skills.radiation_shield;
                    }
                    else if (coef < 0 && Singleton.skills.radiation_shield > 0)
                    {
                        --Singleton.skills.radiation_shield;
                        Singleton.player.carbon -= (int)coef;
                    }
                    progress.value = (float)Singleton.skills.radiation_shield / Singleton.skills.radiation_shield_max * 100f;
                    if (Singleton.skills.radiation_shield < Singleton.skills.radiation_shield_max)
                    {
                        text.text = string.Format("��� �� �������� ({0} ���.)", Mathf.RoundToInt(price * value * progress.value / 100f * Singleton.skills.radiation_shield_max) + 5);
                    }
                    else
                    {
                        text.text = "��� �� �������� (����.)";
                    }
                }
                break;
            case 4:
                if (is_carbon_enough(Singleton.skills.vertical_velocity_max, coef))
                {
                    if (coef > 0 && Singleton.skills.vertical_velocity < Singleton.skills.vertical_velocity_max)
                    {
                        Singleton.player.carbon -= Mathf.RoundToInt(coef * value * progress.value / 100f * Singleton.skills.vertical_velocity_max) + 5;
                        ++Singleton.skills.vertical_velocity;
                    }
                    else if (coef < 0 && Singleton.skills.vertical_velocity > 0)
                    {
                        --Singleton.skills.vertical_velocity;
                        Singleton.player.carbon -= (int)coef;
                    }
                    progress.value = (float)Singleton.skills.vertical_velocity / Singleton.skills.vertical_velocity_max * 100f;
                    if (Singleton.skills.vertical_velocity < Singleton.skills.vertical_velocity_max)
                    {
                        text.text = string.Format("������������ �������� ({0} ���.)", Mathf.RoundToInt(price * value * progress.value / 100f * Singleton.skills.vertical_velocity_max) + 5);
                    }
                    else
                    {
                        text.text = "������������ �������� (����.)";
                    }
                }
                break;
            case 5:
                if (is_carbon_enough(Singleton.skills.horizontal_velocity_max, coef))
                {
                    if (coef > 0 && Singleton.skills.horizontal_velocity < Singleton.skills.horizontal_velocity_max)
                    {
                        Singleton.player.carbon -= Mathf.RoundToInt(coef * value * progress.value / 100f * Singleton.skills.horizontal_velocity_max) + 5;
                        ++Singleton.skills.horizontal_velocity;
                    }
                    else if (coef < 0 && Singleton.skills.horizontal_velocity > 0)
                    {
                        --Singleton.skills.horizontal_velocity;
                        Singleton.player.carbon -= (int)coef;
                    }
                    progress.value = (float)Singleton.skills.horizontal_velocity / Singleton.skills.horizontal_velocity_max * 100f;
                    if (Singleton.skills.horizontal_velocity < Singleton.skills.horizontal_velocity_max)
                    {
                        text.text = string.Format("�������������� �������� ({0} ���.)", Mathf.RoundToInt(price * value * progress.value / 100f * Singleton.skills.horizontal_velocity_max) + 5);
                    }
                    else
                    {
                        text.text = "�������������� �������� (����.)";
                    }
                }
                break;
        }
        Singleton.player.UpdateCarbonCounterText();
    }

    bool is_carbon_enough(int max_count, float coef)
    {
        return Singleton.player.carbon >= coef * value * progress.value / 100f * max_count + 5;
    }
}
