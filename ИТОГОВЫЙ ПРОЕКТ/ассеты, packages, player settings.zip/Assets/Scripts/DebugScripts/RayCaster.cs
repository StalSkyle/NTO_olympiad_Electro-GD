using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[ExecuteAlways]
public class RayCaster : MonoBehaviour
{
    [Range(0, 1800)]
    public int count_of_rays = 10;
    [Range(0, 100)]
    public float max_distance = 1f;
 
    void Update()
    {
        for(int i=0; i<count_of_rays; i++)
        {
            RaycastHit hit;
            if(Physics.Raycast(new Ray(transform.position, Quaternion.Euler(0, 0, i * 360f / count_of_rays) * Vector3.up), out hit, max_distance))
            {
                Debug.DrawLine(transform.position, hit.point, Color.green);
            }
            else
            {
                Debug.DrawLine(transform.position, transform.position + Quaternion.Euler(0, 0, i * 360f / count_of_rays) * Vector3.up * max_distance, Color.red);
            }
        }
    }
}
