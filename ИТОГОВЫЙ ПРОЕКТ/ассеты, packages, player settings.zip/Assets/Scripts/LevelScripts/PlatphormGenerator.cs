using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlatphormGenerator : MonoBehaviour
{
    public float time_counter;
    public int lines_counter = 0;
    public List<GameObject> lines = new List<GameObject>();

    List<Vector3> carb_buffer = new List<Vector3>();

    int created_carbon_number = 0;

    public GameObject block;
    public GameObject carbon;
    public GameObject RadiationGenerator;
    public GameObject line;
    public GameController game;
    public float time_interval = 5f;
    public float generation_chance = 0.667f;
    public float rad_generation_chance = 0.2f;
    public int line_length = 18;
    public float speed = 0.02f;
    public float dispression = 0f;

    // Start is called before the first frame update
    void Awake()
    {
        time_counter = Time.time - time_interval;
    }

    public GameObject GetLastLine()
    {
        return lines[lines.Count - 1];
    }

    void Generate(int length)
    {
        lines.Add(Instantiate(line));
        bool flag = true;
        bool flag2 = true;
        for(int i = 0; i <= length; i++)
        {
            if (Random.value < generation_chance && (i != length || !flag))
            {
                GameObject c = Instantiate(block);
                c.transform.position = new Vector3(i - length / 2f, Random.value * dispression, 0);
                c.transform.SetParent(lines[lines.Count - 1].transform);
                c.SetActive(true);
                if(flag2 && Random.value < rad_generation_chance)
                {
                    GameObject rg = Instantiate(RadiationGenerator);
                    rg.transform.position = c.transform.position + Vector3.up * 0.8f;
                    rg.transform.SetParent(lines[lines.Count - 1].transform);
                    rg.SetActive(true);
                    rg.AddComponent<RadiationGenerator>();
                    rg.GetComponent<RadiationGenerator>().radzone_material = RadiationGenerator.GetComponent<RadiationGenerator>().radzone_material;
                    float N = Random.Range(0.6f, 1.2f);
                    rg.transform.GetChild(0).localScale = new Vector3(N*0.36f, 0.0003324375f, N*0.21f);
                }
            }
            else
            {
                flag = false;
            }
        }
        lines[lines.Count - 1].AddComponent<LineController>();
        lines[lines.Count - 1].GetComponent<LineController>().generator = this;
        lines[lines.Count - 1].transform.SetParent(GameObject.Find("SceneObjects").transform);
        lines[lines.Count - 1]?.SetActive(true);

        carb_buffer.Clear();

        int n = Random.Range(1, 5);
        for (int i = 0; i < n; i++)
        {
            carb_buffer.Add(new Vector3(Random.Range(-9, 9), (int)Random.Range(2, time_interval * speed * 100 - 2), 0));
        }
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        if (GameController.IsPlay)
        {
            if (Time.time - time_counter >= time_interval)
            {
                Generate(line_length);
                time_counter = Time.time;
                ++lines_counter;
                if (lines_counter % 5 == 0)
                {
                    speed += 0.01f;
                    time_interval = (speed - 0.01f) * time_interval / speed;
                    generation_chance += 0.05f;
                    StartCoroutine(game.NextSkyLevel());
                }
            }
            else if (carb_buffer.Find(x => x.y == (int)((Time.time - time_counter) * speed * 100)) != Vector3.zero)
            {
                GameObject c = Instantiate(carbon);
                c.transform.position = carb_buffer.Find(x => x.y == (int)((Time.time - time_counter) * speed * 100));
                carb_buffer.Remove(c.transform.position);
                c.transform.position = new Vector3(c.transform.position.x, 10, 0);
                c.AddComponent<BoostsController>();
                c.GetComponent<BoostsController>().generator = this;
                c.SetActive(true);
                c.tag = "carbon";
                c.transform.SetParent(GameObject.Find("SceneObjects").transform);
            }
            if (lines_counter > 25)
            {
                StartCoroutine(game.Win());
                lines_counter = 0;
            }
        }
    }

    public void ResetValues()
    {
        time_counter = Time.time - time_interval;
        lines_counter = 0;
        time_interval = 5f;
        generation_chance = 0.5f;
        rad_generation_chance = 0.1f;
        line_length = 18;
        speed = 0.02f;
        lines.Clear();
    }
}
