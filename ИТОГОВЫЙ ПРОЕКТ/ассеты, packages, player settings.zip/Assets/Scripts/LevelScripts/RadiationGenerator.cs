using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RadiationGenerator : MonoBehaviour
{
    GameObject zone;

    float delay_begin = 0;

    public Material radzone_material;

    public float player_shield = 0;

    // Start is called before the first frame update
    void Awake()
    {
        zone = transform.GetChild(0).gameObject;
        zone.tag = "radzone";
        zone.GetComponent<MeshRenderer>().material = Instantiate(radzone_material);
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        player_shield = Mathf.Clamp01(0.2f * Singleton.skills.radiation_shield + Singleton.player.damage_shield);
    }

    public void DamagePlayer(GameObject player)
    {
        if (Time.time - delay_begin > 0.1f)
        {
            float dist = Vector3.Distance(transform.position, player.transform.position);
            player.GetComponent<PlayerController>().health -= (2f / (0.5f * dist + 0.2f) * (1 - player_shield));
            zone.GetComponent<MeshRenderer>().material.color = new Color(1, 1, 1, 44f / 255f + (5f - dist) / 10f);
            delay_begin = Time.time;
        }
    }
}