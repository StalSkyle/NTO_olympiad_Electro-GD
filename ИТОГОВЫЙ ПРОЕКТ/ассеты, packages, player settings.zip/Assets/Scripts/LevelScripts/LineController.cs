using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LineController : MonoBehaviour
{
    public PlatphormGenerator generator;

    // Start is called before the first frame update
    void Awake()
    {
        
        transform.position = new Vector3(0, 10, 0);
        tag = "line";
        name = "Line";
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        if (GameController.IsPlay)
        {
            transform.position += Vector3.down * generator.speed;
            if (transform.position.y < -10)
                Destroy(gameObject);
        }
    }
}
