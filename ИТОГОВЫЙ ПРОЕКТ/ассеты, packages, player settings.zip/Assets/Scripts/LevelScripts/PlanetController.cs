using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlanetController : MonoBehaviour
{
    public float delay_begin;
    // Start is called before the first frame update
    void Awake()
    {
        delay_begin = Time.time;
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        if (GameController.IsPlay)
        {
            if (Time.time - delay_begin >= 1f)
            {
                transform.position += Vector3.down * 0.02f;
            }
        }
    }
}
