using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Singleton : MonoBehaviour
{
    static public GameController game;
    static public PlayerController player;
    static public PlanetController planet;
    static public PlayerSkillsController skills;
    static public UIController ui_controller;
    static public PlatphormGenerator generator;

    // Start is called before the first frame update
    void Awake()
    {
        game = GameObject.Find("GameObject").GetComponent<GameController>();
        player = GameObject.Find("Player").GetComponent<PlayerController>();
        planet = GameObject.Find("Planet").GetComponent<PlanetController>();
        skills = GameObject.Find("Player").GetComponent<PlayerSkillsController>();
        ui_controller = GameObject.Find("GameObject").GetComponent<UIController>();
        generator = GameObject.Find("GameObject").GetComponent<PlatphormGenerator>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
