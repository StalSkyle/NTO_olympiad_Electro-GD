using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameController : MonoBehaviour
{
    public GameObject defeat;
    public GameObject win;
    public GameObject lines_counter;
    public GameObject scene_objects;
    public GameObject player;
    public GameObject lines_generator;
    public GameObject background;
    public GameObject planet;
    public List<Material> background_materials;
    public int sky_level_number = 0;

    public static bool IsPlay = false;

    private void Start()
    {
        IsPlay = true;
    }

    // Start is called before the first frame update
    void Awake()
    {
        player.GetComponent<Rigidbody>().useGravity = false;
        player.GetComponent<MeshCollider>().isTrigger = true;
        player.GetComponent<Rigidbody>().velocity = new Vector3(0, 0, 0);
        player.transform.position = new Vector3(0, -2.5f, 0);
        planet.transform.position = new Vector3(0, -7.85f, 0);
        player.GetComponent<MeshRenderer>().material.color = new Color(188 / 255f, 167 / 255f, 91 / 255f);
        player.GetComponent<PlayerController>().health = 100f;
        background.GetComponent<MeshRenderer>().material = background_materials[0];
        player.transform.GetChild(0).GetComponent<Light>().spotAngle = 179;
        lines_counter.GetComponent<Text>().text = "0";
        sky_level_number = 0;
    }

    // Update is called once per frame
    void FixedUpdate()
    {

    }

    public IEnumerator Defeat()
    {
        defeat.SetActive(true);
        yield return new WaitForSeconds(1);
        for (int i = 0; i < scene_objects.transform.childCount; i++)
        {
            Destroy(scene_objects.transform.GetChild(i).gameObject);
        }
        defeat.SetActive(false);
        player.GetComponent<Rigidbody>().useGravity = false;
        player.GetComponent<MeshCollider>().isTrigger = true;
        player.GetComponent<Rigidbody>().velocity = new Vector3(0, 0, 0);
        player.transform.position = new Vector3(0, -2.5f, 0);
        planet.transform.position = new Vector3(0, -7.85f, 0);
        player.GetComponent<MeshRenderer>().material.color = new Color(188 / 255f, 167 / 255f, 91 / 255f);
        Singleton.player.health = 100f;
        lines_generator.GetComponent<PlatphormGenerator>().ResetValues();
        background.GetComponent<MeshRenderer>().material = background_materials[0];
        player.transform.GetChild(0).GetComponent<Light>().spotAngle = 179;
        lines_counter.GetComponent<Text>().text = "0";
        sky_level_number = 0;

        Singleton.ui_controller.OpenImproveMenu();
    }

    public IEnumerator NextSkyLevel()
    {
        ++sky_level_number;
        Debug.Log(sky_level_number);
        background.GetComponent<MeshRenderer>().material.color = new Color(1, 1, 1, 0);
        background.GetComponent<MeshRenderer>().material = background_materials[sky_level_number];
        //background.transform.GetChild(0).GetComponent<MeshRenderer>().material.color = new Color(1, 1, 1, 1);
        //background.transform.GetChild(0).GetComponent<MeshRenderer>().material = background_materials[sky_level_number - 1];
        for (int i = 0; i < 30; i++)
        {
            if(player.transform.GetChild(0).GetComponent<Light>().spotAngle > 70)
                player.transform.GetChild(0).GetComponent<Light>().spotAngle -= 7f / (background_materials.Count - 1);
            background.GetComponent<MeshRenderer>().material.color = new Color(1, 1, 1, i / 30f + 0.0333f);
            //background.transform.GetChild(0).GetComponent<MeshRenderer>().material.color = new Color(1, 1, 1, 0.9667f - i / 30f);
            yield return new WaitForSeconds(0.0666f);
        }
        /*background.transform.GetChild(0).GetComponent<MeshRenderer>().material = background_materials[sky_level_number];
        background.transform.GetChild(0).GetComponent<MeshRenderer>().material.color = new Color(1, 1, 1, 1);*/
    }

    public IEnumerator Win()
    {
        lines_generator.GetComponent<PlatphormGenerator>().time_counter = float.PositiveInfinity;
        yield return new WaitForSeconds(Time.fixedDeltaTime * 20 / lines_generator.GetComponent<PlatphormGenerator>().speed);
        //Singleton.player.carbon = -100;
        Singleton.player.speed = 0;
        for (int i = 0; i < 180; i++) {
            Camera.main.transform.Rotate(Vector3.forward, 1);
            player.transform.Rotate(Vector3.down, 1);
            player.transform.position = Vector3.Slerp(player.transform.position, new Vector3(0, -2.75f, 0), i / 180f);
            yield return new WaitForSeconds(0.0167f);
        }
        planet.transform.position = new Vector3(0, 10, 0);
        yield return new WaitForSeconds(Time.fixedDeltaTime * 375);
        Singleton.planet.delay_begin = float.PositiveInfinity;

        win.SetActive(true);
        yield return new WaitForSeconds(1);
        win.SetActive(false);
        player.GetComponent<Rigidbody>().velocity = new Vector3(0, 0, 0);
        player.transform.position = new Vector3(0, -2.5f, 0);
        planet.transform.position = new Vector3(0, -7.85f, 0);
        player.GetComponent<MeshRenderer>().material.color = new Color(188 / 255f, 167 / 255f, 91 / 255f);
        Singleton.player.health = 100f;
        lines_generator.GetComponent<PlatphormGenerator>().ResetValues();
        background.GetComponent<MeshRenderer>().material = background_materials[0];
        background.transform.GetChild(0).GetComponent<MeshRenderer>().material = background_materials[0];
        player.transform.GetChild(0).GetComponent<Light>().spotAngle = 179;
        Camera.main.transform.rotation = Quaternion.Euler(0, 0, 0);
        player.transform.rotation = Quaternion.Euler(-90, 0, 0);
        lines_counter.GetComponent<Text>().text = "0";
        sky_level_number = 0;

        Singleton.planet.delay_begin = Time.time;
        //Singleton.player.carbon = 0;
        Singleton.player.speed = 0.02f;

        Singleton.ui_controller.OpenImproveMenu();
    }
}