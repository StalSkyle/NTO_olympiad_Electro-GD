using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class UIController : MonoBehaviour
{
    public Canvas menu;
    public Canvas settings;
    public Canvas game;
    public Canvas tutorial;
    public Canvas improve;
    public Canvas loading;

    public Slider slider;

    public ProgressBarController loading_progress;

    public Text game_name;

    public Gradient gradient;

    public GameObject ability_button;

    public static float music_volume = 1;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (slider == null)
        {
            Camera.main.GetComponent<AudioSource>().volume = music_volume;
        }
        else
        {
            Camera.main.GetComponent<AudioSource>().volume = slider.value;
            music_volume = slider.value;
        }
        if (game_name != null)
        {
            game_name.color = gradient.Evaluate(Mathf.Abs((Time.time % 2) - 1));
        }
    }

    public void OnPlayButtonClicked()
    {
        menu.gameObject.SetActive(false);
        loading.gameObject.SetActive(true);
        StartCoroutine(Loding());
        GameController.IsPlay = true;
    }

    public void OnSettingsButtonClicked()
    {
        menu.gameObject.SetActive(false);
        settings.gameObject.SetActive(true);
    }

    public void OnBackButtonClicked()
    {
        if (SceneManager.GetActiveScene().name == "Game")
        {
            SceneManager.LoadScene("Menu");
        }
        GameController.IsPlay = false;
        settings.gameObject.SetActive(false);
        tutorial.gameObject.SetActive(false);
        menu.gameObject.SetActive(true);
    }

    public void OnTutorialButtonClicked()
    {
        menu.gameObject.SetActive(false);
        tutorial.gameObject.SetActive(true);
    }

    public void OnExitButtonClicked()
    {
        Application.Quit();
    }

    public void OpenImproveMenu()
    {
        improve.gameObject.SetActive(true);
        GameController.IsPlay = false;
    }
    public void OnApplyButtonClicked()
    {
        improve.gameObject.SetActive(false);
        ability_button.GetComponent<AbilityActivator>().ability_type = Singleton.player.chosen_ability;
        if (Singleton.player.chosen_ability > -1) {
            ability_button.SetActive(true);
        }
        else
        {
            ability_button.SetActive(false);
        }
        GameController.IsPlay = true;
        Singleton.generator.speed = 0.02f + Singleton.skills.vertical_velocity * 0.02f;
        Singleton.generator.time_interval = 0.02f * Singleton.generator.time_interval / Singleton.generator.speed;
        ability_button.GetComponent<AbilityActivator>().activation_count = 0;
    }
    public IEnumerator Loding()
    {
        var asyncLoad = SceneManager.LoadSceneAsync("FirstTimelinePart1");
        while (!asyncLoad.isDone)
        {
            loading_progress.value = asyncLoad.progress * 100f;
            yield return null;
        }
    }
}
