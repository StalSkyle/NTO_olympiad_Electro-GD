using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ProgressBarController : MonoBehaviour
{
    GameObject line;

    public float value;

    public enum ProgressBarType
    {
        Center,
        Left,
    }
    public ProgressBarType type;

    // Start is called before the first frame update
    void Start()
    {
        line = transform.GetChild(0).gameObject;
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        if (type == ProgressBarType.Center)
        {
            line.transform.localScale = new Vector3(0.9829414f * value / 100f, 0.78479f, 1);
        }
        else
        {
            line.transform.localPosition = new Vector3(-0.9829414f * value / 200f, 0, 0);
            line.transform.localScale = new Vector3(0.9829414f * value / 100f, 0.78479f, 1);
        }
    }
}
