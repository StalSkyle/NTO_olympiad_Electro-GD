using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BoostsController : MonoBehaviour
{
    public static Dictionary<string, System.Action<PlayerController>> effects = new Dictionary<string, System.Action<PlayerController>>() {
        { "carbon", new System.Action<PlayerController>(x => { x.carbon += carbon_price; if(x.health <= 96f) x.health += 4; }) }
    };

    public PlatphormGenerator generator;

    public static int carbon_price = 1;

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void FixedUpdate()
    {
        if (GameController.IsPlay)
        {
            transform.position += Vector3.down * generator.speed;
            if (transform.position.y < -10)
                Destroy(gameObject);
        }
    }

    public void Collect(PlayerController player)
    {
        effects[gameObject.tag](player);
        Destroy(gameObject);
    }
}
