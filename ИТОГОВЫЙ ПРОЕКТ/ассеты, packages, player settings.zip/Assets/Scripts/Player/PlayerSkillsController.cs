using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerSkillsController : MonoBehaviour
{
    //�����������
    public int damage_shield = 0;
    public int carbon_price_upper = 0;
    public int blocks_destroyer = 0;

    public int damage_shield_max = 5;
    public int carbon_price_upper_max = 5;
    public int blocks_destroyer_max = 5;
    //������
    public int radiation_shield = 0;
    public int vertical_velocity = 0;
    public int horizontal_velocity = 0;

    public int radiation_shield_max = 5;
    public int vertical_velocity_max = 5;
    public int horizontal_velocity_max = 5;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
