using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerCollisionController : MonoBehaviour
{
    public Text gameOverText;

    //public GameController game;

    public Text linesCountText;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "block")
        {
            GetComponent<MeshCollider>().isTrigger = false;
            GetComponent<Rigidbody>().useGravity = true;
            StartCoroutine(Singleton.game.Defeat());
        }
        else if(BoostsController.effects.ContainsKey(other.tag))
        {
            other.GetComponent<BoostsController>().Collect(GetComponent<PlayerController>());
        }
    }
    private void OnTriggerStay(Collider other)
    {
        if (other.tag == "radzone")
        {
            other.GetComponentInParent<RadiationGenerator>().DamagePlayer(gameObject);

            GetComponent<MeshRenderer>().material.color = new Color(1, 0.3922f, 0.3922f, 1);

            if (GetComponent<PlayerController>().health <= 0)
            {
                GetComponent<MeshCollider>().isTrigger = false;
                GetComponent<Rigidbody>().useGravity = true;
                StartCoroutine(Singleton.game.Defeat());
            }
        }
    }
    private void OnTriggerExit(Collider other)
    {
        if (other.tag == "radzone")
        {
            GetComponent<MeshRenderer>().material.color = new Color(188 / 255f, 167 / 255f, 91 / 255f);
        }
        else if (other.tag == "line")
        {
            linesCountText.text = (int.Parse(linesCountText.text) + 1).ToString();
        }
    }
}
