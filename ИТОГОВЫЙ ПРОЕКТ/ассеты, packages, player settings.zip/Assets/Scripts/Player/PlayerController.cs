using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerController : MonoBehaviour
{
    public float speed = 0.02f;
    public Vector2 bolds = new Vector2(-9.5f, 9.5f);
    //public Dictionary<string, int> boosters_count = new Dictionary<string, int>() { { "carbon", 0 } };
    public int carbon = 0;
    public float health = 100f;
    public ProgressBarController hp_bar;

    public float damage_shield;
    public float ability_start_time;
    public int chosen_ability = -1;

    public Text carbonCountText1;
    public Text carbonCountText2;

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void FixedUpdate()
    {
        if (GameController.IsPlay)
        {
            speed = (Singleton.skills.horizontal_velocity + 1) * 0.02f;
            if (Input.GetKey(KeyCode.A) || Input.touchCount > 0 && Input.GetTouch(0).position.x < Screen.width / 2)
            {
                transform.position += Vector3.left * speed;
            }
            if (Input.GetKey(KeyCode.D) || Input.touchCount > 0 && Input.GetTouch(0).position.x > Screen.width / 2)
            {
                transform.position += Vector3.right * speed;
            }
            transform.position = new Vector3(Mathf.Clamp(transform.position.x, bolds.x, bolds.y), transform.position.y, 0);
            hp_bar.value = health;
            UpdateCarbonCounterText();
        }
    }

    public void UpdateCarbonCounterText()
    {
        carbonCountText1.text = string.Format("� ���� {0} ��������", carbon);
        carbonCountText2.text = string.Format("� ���� {0} ��������", carbon);
    }
}
